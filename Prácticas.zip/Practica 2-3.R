# Práctica 2.3
# Genera un vector de ruido blanco de 3000 observaciones

# Calcula el test de Ljung-Box para ese ruido y
# 26 retardos (usa la función "Box.test")

# Calcula el test de Ljung-Box para ese ruido
# para retardos de 1 a 38

# Carga en memoria la serie ipi y analiza la 
# autocorrelación con las ACF y PACF y el test de
# Ljung-Box

# Analiza el pib español

# Analiza la bolsa española

# Supongamos que la serie bolsa es un paseo
# aleatorio, examina la serie d(t)=bolsa(t)-bolsa(t-1)

