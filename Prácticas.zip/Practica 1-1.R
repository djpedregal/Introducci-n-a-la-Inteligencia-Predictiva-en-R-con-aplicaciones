# Práctica #1.1
# Comprueba la carpeta de trabajo

# Mira los archivos que hay en el directorio por defecto

# Mira las variables que tienes en memoria

# Borra todas las variables de memoria

# Crea dos matrices aleatorias de dimensión 4 x 2 y 
# asígnalas a las variables a y b (tienes que usar
# "runif" y "matrix")

# Calcula la matriz transpuesta de b

# Calcula a+b, a-b, a*b'

# Genera un ruido aleatorio de longitud 3000, 
# procedente de una distribución uniforme.

# Calcula la media y la varianza

# Modifícala para que la media sea
# exactamente 0 y la varianza exactamente 1. Comprobar 
# la forma de la distribución con un histograma.

# Repite el ejercicio anterior para una distribución N(0, 1)

# Borra la ventana de gráficos


