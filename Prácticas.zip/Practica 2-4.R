# Práctica 2.4
# Carga los datos de ipi y represéntalos

# Calcula el lambda de la trasformación Box-Cox
# con la función "BoxCox.lambda" y la serie 
# transformada con el lambda óptimo 
# con la función "BoxCox"
# Representa la serie transformada.

# Muestra la serie transformada con:
#   1) Una diferencia regular
#   2) Una diferencia estacional
#   3) Una diferencia regular y una estacional

# Busca la transformación de varianza y
# media adecuadas para los pasajeros de avión

# Repite el análisis para el pib

